$(document).ready(function() {
  console.log('BASE_URL ----> ' + base_url);
  $('#myTable').DataTable({
    "ajax": base_url + '/customers/get-customers'
  });
});

var data = [
  [
      "Tiger Nixon",
      "System Architect",
      "Edinburgh",
      "5421",
      "2011/04/25",
      "$3,120"
  ],
  [
      "Garrett Winters",
      "Director",
      "Edinburgh",
      "8422",
      "2011/07/25",
      "$5,300"
  ]
]