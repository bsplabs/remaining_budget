<?php

// Load Composer Libs
// require_once '../vendor/autoload.php';
// echo "<pre>";
// print_r($_SERVER);
// echo "</pre>";

// exit;

// Load require file
require_once("./../app/require.php");

?>