<?php

require_once ROOTPATH . "/app/vendors/PHPExcel/PHPExcel/IOFactory.php";

class ReportsController extends Controller
{
  private $reportModel;
  private $resourceModel;
  protected $generateRemainingBudget = false;
  protected $month;
  protected $year;

  public function __construct()
  {
    $this->reportModel = $this->model("Report");
    $this->resourceModel = $this->model("Resource");
    $last_month_timestamp =  strtotime("-1 month");
    $this->month = date("m", $last_month_timestamp);
    $this->year = date("Y");
  }

  public function index($year = "", $month = "")
  {
    if ($month == "" || $year == "") {
      $month = $this->month;
      $year = $this->year;
    }

    // validate month year uri params
    if (intval($month + $year) > intval($this->month + $this->year)) {
      header("Location: " . BASE_URL);
    } 

    $data["month_year_selected"] = $month . "_" . $year;
    $month_year_lists = array();
    $getMonthYearLists = $this->reportModel->getMonthYearLists();
    // print_r($getMonthYearLists);
    if ($getMonthYearLists["status"] === "success" && !empty($getMonthYearLists["data"])) {
      foreach ($getMonthYearLists["data"] as $key => $my) {
        $month_year_lists[$my["month"] . "_" . $my["year"]] = $this->parseMonthYear($my["month"], $my["year"]);
      }
    } else {
      $month_year_lists[$data["month_year_selected"]] = $this->parseMonthYear($month, $year);
    }
    $data["month_year_lists"] = $month_year_lists;
    $data["month"] = $month;
    $data["year"] = $year;
    $data["page_name"] = $this->findPageName();

    // check report status
    $reportStatus = $this->reportModel->getReporttStatus($month, $year);
    if ($reportStatus["status"] === "success" && empty($reportStatus["data"])) {
      // insert or initialize report status table
      $this->reportModel->createReportStatus($month, $year);
      $reportStatus["data"]["overall_status"] = "pending";
    }
    // $data["overall_status"] = $reportStatus["data"]["overall_status"];

    // Render view
    $this->view('layout/header', array("title" => "Reports - The Remaining Budget"));
    if ($reportStatus["status"] === "success" && $reportStatus["data"]["overall_status"] === "completed") {
      $this->view('report/reconcile', $data);
    } else if ($reportStatus["status"] === "success" && $reportStatus["data"]["overall_status"] === "pending") {
      $this->view('report/index', $data);
      // if ($month < $this->month || $year < $this->year) {
      //   $this->view('report/broken_data', $data);
      // } else {
      //   $this->view('report/index', $data);
      // }
    } else if ($reportStatus["status"] === "success" && $reportStatus["data"]["overall_status"] === "waiting") {
      $this->view('report/processing', $data);
    } else {
      $this->view('report/error');
    }
    $this->view('layout/footer');

  }

  public function reconcile()
  {
    $data["page_name"] = $this->findPageName();
    if (!$this->generateRemainingBudget) {
      header("Location: /reports");
    }

    $data = array();
    $data["report_data"] = $this->reportModel->gropParentID();
    $data["report_data"] = $data["report_data"]["data"];
    $rembudgetBasic = $this->reportModel->getBasicRemainingBudgetValue();
    $data["testData"] = $rembudgetBasic["data"];
    $this->view('layout/header', array("title" => "Reports - The Remaining Budget"));
    $this->view('report/reconcile', $data);
    $this->view('layout/footer');
  }

  public function generate()
  {
    $this->generateRemainingBudget = true;
    header("Location: /reports/reconcile");
  }

  public function uploadCashAdvance()
  {
    header("Content-Type: application/json");
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      $allowedFileType = array(
        // 'application/vnd.ms-excel',
        'text/xls',
        'text/xlsx',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      );
      if (in_array($_FILES["cashAdvanceInputFile"]["type"], $allowedFileType)) {
        $targetPath = ROOTPATH . "/public/uploads/gl_cash_advance/{$this->month}-{$this->year}/" . $_FILES["cashAdvanceInputFile"]["name"];
        $dirGLCashAdvanceFile = dirname($targetPath);
        if (!file_exists($dirGLCashAdvanceFile)) {
          if (!mkdir($dirGLCashAdvanceFile, 0777, true)) {
            $res = array(
              "status" => "error",
              "type" => "alert",
              "message" => "Can't create folder for store gl_cash_advance file",
              "data" => ""
            );
            echo json_encode($res);
            exit;
          }
        }

        if (move_uploaded_file($_FILES["cashAdvanceInputFile"]["tmp_name"], $targetPath)) {
          $ignore_invalid_data = false;
          if (isset($_POST["ignore_invalid_data"])) {
            $ignore_invalid_data = $_POST["ignore_invalid_data"];
          }
          $this->importCashAdvanceData($targetPath, $this->month, $this->year, $ignore_invalid_data);
          $res = array(
            "status" => "success",
            "type" => "alert",
            "message" => ""
          );
          // echo json_encode($res);
        } else {
          echo "Can not move file";
        }
      } else {
        $res = array(
          "status" => "error",
          "type" => "alert",
          "message" => "File type not allowed",
          "data" => ""
        );
        echo json_encode($res);
      }
    } else {
      $res = array(
        "status" => "error",
        "type" => "alert",
        "message" => "Allowed only POST method",
        "data" => ""
      );
      echo json_encode($res);
    }
  }

  public function importCashAdvanceData($filePath, $month, $year, $ignore_invalid_data)
  {
    $objPHPExcel = PHPExcel_IOFactory::load($filePath);
    $excelSheet = $objPHPExcel->getActiveSheet();
    $highestRow = $excelSheet->getHighestRow(); // e.g. 10

    $glCodeWhiteLists = array("212412", "212413", "212415", "412112");

    $glCashAdvance = array();
    $total = 0;
    $valid_total = 0;
    $invalid_total = 0;
    $invalid_lists = array();

    $month_year_error = false;
    $debit_error = false;
    $credit_error = false;

    for ($row = 1; $row <= $highestRow; ++$row) {

      $glCode = $excelSheet->getCell("F" . $row)->getValue();
      if (empty($glCode) || !is_numeric($glCode)) {
        if (!in_array($glCode, $glCodeWhiteLists)) {
          continue;
        }
      }

      $total++;
      $postingDate = $excelSheet->getCell("A" . $row)->getValue();
      $dueDate = $excelSheet->getCell("B" . $row)->getValue();
      $series = $excelSheet->getCell("C" . $row)->getValue();
      $docNo = $excelSheet->getCell("D" . $row)->getValue();
      $transNo = $excelSheet->getCell("E" . $row)->getValue();
      // check date mathing
      $exp_posting_date = explode(".", $postingDate);
      $report_month = $exp_posting_date[1];
      $report_year = $exp_posting_date[2];
      if (strlen($report_year) == 2) {
        $report_year = $year[0] . $year[1] . $report_year;
      } 

      $internal_loop_error = false;

      if ($report_month != $month || $report_year != $year) {
        array_push($invalid_lists, array(
          "trans_no" => $transNo,
          "error_message" => "month and year (posting date) do not match with last month and year"
        ));
        $invalid_total++;
        $internal_loop_error = true;
        $month_year_error = true;
      }

      if (intval($report_month + $report_year) > intval($month + $year)) {
        array_push($invalid_lists, array(
          "trans_no" => $transNo,
          "error_message" => "month and year (posting date) are more than last month and year"
        ));
        $invalid_total++;
        $internal_loop_error = true;
        $month_year_error = true;
      } 

      $debitLc = $excelSheet->getCell("J" . $row)->getValue();
      $creditLc = $excelSheet->getCell("K" . $row)->getValue();
      // check debit and credit
      if (!is_numeric($debitLc)) {
        if ($debitLc != "") {
          array_push($invalid_lists, array(
            "trans_no" => $transNo,
            "error_message" => "Debit (LC) must be numeric"
          ));
          $invalid_total++;
          $internal_loop_error = true;
          $debit_error = true;
        }
      }

      if (!is_numeric($creditLc)) {
        if ($creditLc != "") {
          array_push($invalid_lists, array(
            "trans_no" => $transNo,
            "error_message" => "Credit(LC) must be numeric"
          ));
          $invalid_total++;
          $internal_loop_error = true;
          $credit_error = true;
        }
      }

      if ($internal_loop_error) continue;
      
      // glCode = ...;
      $remarks = $excelSheet->getCell("G" . $row)->getValue();
      $offsetAcct = $excelSheet->getCell("H" . $row)->getValue();
      $offsetAcctName = $excelSheet->getCell("I" . $row)->getValue();
      $cumulativeBalanceLc = $excelSheet->getCell("L" . $row)->getValue();
      $seriesPrefix = $series[0] . $series[1];

      array_push($glCashAdvance, array(
        "posting_date" => $postingDate,
        "due_date" => $dueDate,
        "series" => $series,
        "doc_no" => $docNo,
        "trans_no" => $transNo,
        "gl_code" => $glCode,
        "remarks" => $remarks,
        "offset_acct" => $offsetAcct,
        "offset_acct_name" => $offsetAcctName,
        "debit_lc" => $debitLc,
        "credit_lc" => $creditLc,
        "cumulative_balance_lc" => $cumulativeBalanceLc,
        "series_code" => $seriesPrefix,
        "month" => $month,
        "year" => $year
      ));
      $valid_total++;
    }

    if (!$ignore_invalid_data && $invalid_total > 0) {
      $err_type = array();
      if ($month_year_error) {
        array_push($err_type, "Posting Date");
      }
      if ($debit_error) {
        array_push($err_type, "Debit (LC)");
      }
      if ($credit_error) {
        array_push($err_type, "Credit (LC)");
      }
      $response = array(
        "status" => "error",
        "type" => "modal",
        "data" => array(
          "total" => $total,
          "valid_total" => $valid_total,
          "invalid_total" => $invalid_total,
          "error_type_lists" => $err_type,
          "invalid_lists" => $invalid_lists,

        )
      );
      echo json_encode($response);
      return 0;
    }

    if ($valid_total == 0) {
      $response = array(
        "status" => "error",
        "type" => "alert",
        "data" => "",
        "message" => "There are not any valid data to import"
      );
      echo json_encode($response);
      return 0;
    }

    // clear gl cash advance 
    $this->reportModel->clearGLCashAdvance($month, $year);
    
    foreach ($glCashAdvance as $key => $val) {
      $customerID = $this->reportModel->checkCustomerExists($val["offset_acct"], $val["offset_acct_name"]);
      if (empty($customerID["data"])) {
        // insert and get id
        $customerID = $this->reportModel->insertNewCustomer($val["offset_acct"], $val["offset_acct_name"]);
        // array_push($offsetAcctAddNew, $offsetAcct);
      } else {
        // array_push($offsetAcctUpdate, $offsetAcct);
      }

      $val["remaining_budget_customer_id"] = $customerID["data"];

      // insert
      $this->reportModel->insertGLCashAdvance($val);
    }

    // update report status
    $get_report_status = $this->reportModel->getReporttStatus($month, $year);
    $overall_status = $get_report_status["data"]["overall_status"];
    if (empty($get_report_status["data"])) {
      $this->reportModel->createReportStatus($month, $year);
    } 

    // get import detail of gl cash advance 
    $get_gl_cash_advance_detail = $this->resourceModel->getTotalDataUpdate("gl_cash_advance", $month, $year);
    if ($get_gl_cash_advance_detail["data"]["row_count"] == 0) {
      $this->reportModel->updateReportStatus($month, $year, "gl_cash_advance", "pending");
      $response = array(
        "status" => "error",
        "type" => "alert",
        "data" => "",
        "message" => "GL Cash Advance import failed"
      );
      echo json_encode($response);
    } else {
      $this->reportModel->updateReportStatus($month, $year, "gl_cash_advance", "waiting");

      // $get_status_resources = $this->resourceModel->getStatusResources($month, $year);
      $waiting = 0;
      foreach ($get_report_status["data"] as $rs => $status) {
        if ($rs === "overall_status") continue;

        if ($rs !== "transfer") {
          if ($status === "waiting") $waiting++;
        }
      }
      if ($waiting === 7 && ($overall_status !== "waiting" || $overall_status !== "completed")) {
        $this->reportModel->updateReportStatus($month, $year, "overall_status", "waiting");
        $overall_status = "waiting";
      }

      $response = array(
        "status" => "success",
        "type" => "alert",
        "overall_status" => $overall_status,
        "data" => array(
          "import_total" => $get_gl_cash_advance_detail["data"]["row_count"],
          "updated_at" => $get_gl_cash_advance_detail["data"]["updated_at"]
        )
      );
      echo json_encode($response);
    }
  }

  
  function parseMonthYear($month, $year)
  {
    $date_obj = DateTime::createFromFormat("!m", $month);
    return $date_obj->format("F") . "/" . $year;
  }

}
