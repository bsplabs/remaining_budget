<?php

class ResourcesController extends Controller
{
  private $resourceModel;
  private $reportModel;
  protected $month;
  protected $year;

  public function __construct()
  {
    $this->resourceModel = $this->model("Resource");
    $this->reportModel = $this->model("Report");
    $last_month_timestamp =  strtotime("-1 month");
    $this->month = date("m", $last_month_timestamp);
    $this->year = date("Y");
  }

  public function index()
  {
    // header("Location: ");
  }

  public function getIce()
  {
    $data = $this->resourceModel->getGoogleSpending();
    echo "<pre>";
    print_r($data);
    echo "</pre>";
  }

  public function ice()
  {
    // $this->uploadFacebookSpending();
    // $this->uploadGoogleSpending();
  }

  public function importGoogleSpending()
  {
    header("Content-Type: application/json");
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      $allowedFileType = array(
        'application/vnd.ms-excel',
        // 'text/xls',
        // 'text/xlsx',
        // 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      );

      if (!in_array($_FILES["googleSpendingInputFile"]["type"], $allowedFileType)) {
        $res = array(
          "status" => "fail",
          "type" => "alert",
          "error" => "File type not allowed"
        );
        echo json_encode($res);
        return 0;
      }

      $targetFilePath = $_FILES["googleSpendingInputFile"]["tmp_name"];

      $googleSpending = array();
      $dataIndex = 0;
      // Open the file for reading
      if (($handle = fopen("{$targetFilePath}", "r")) !== FALSE) {
        $rowStartNumber = NULL;  
        for ($i = 0; $row = fgetcsv($handle); ++$i) {
          if ($row[0] === "รหัสบัญชี" && $row[1] === "บัญชี") {
            $rowStartNumber = $i;
            continue;
          }
          if ($rowStartNumber != NULL && $i > $rowStartNumber) {
            $googleSpending[$dataIndex]["google_id"] = $row[0];
            $googleSpending[$dataIndex]["google_account"] = $row[1];
            $googleSpending[$dataIndex]["budget_account"] = $row[2];
            $googleSpending[$dataIndex]["purchase_order"] = $row[3];
            $googleSpending[$dataIndex]["campaign"] = $row[4];
            $googleSpending[$dataIndex]["volume"] = $row[5];
            $googleSpending[$dataIndex]["unit"] = $row[6];
            $googleSpending[$dataIndex]["spending_total_price"] = $row[7];
            $dataIndex++;
          }
        }

        fclose($handle);
      }

      // clear data by month and year
      $this->resourceModel->clearrGoogleSpendingByMonthAndYear($this->month, $this->year);

      foreach ($googleSpending as $idx => $value) 
      {
        // $is_valid_data = true;
        // $import_google_spending_result = array();
        // $import_google_spending_result["google_add_id"] = $value["google_id"];
        
        // Find grandadmin_customer_id
        $find_customer_id = $this->resourceModel->findCustomerID($value, "google");
        if ($find_customer_id["status"] === "success") {
          $value["grandadmin_customer_id"] = $find_customer_id["data"]["CustomerID"];
        } else {
          $value["grandadmin_customer_id"] = "";
        }

        // Find grandadmin_customer_name
        if (empty($value["grandadmin_customer_id"])) {
          $value["grandadmin_customer_name"] = "";
        } else {
          $find_customer_name = $this->resourceModel->findCustomerName($value, "google");
          if (!empty($find_customer_name["data"]) && $find_customer_name["status"] === "success") {
            $value["grandadmin_customer_name"] = $find_customer_name["CustomerName"];
          } else {
            $value["grandadmin_customer_name"] = "";
          }
        }

        // Find remaining_budget_customer_id
        if ($value["grandadmin_customer_name"] !== "" && $value["grandadmin_customer_id"] !== "") {
          $find_remaining_budget_customer_id = $this->resourceModel->findRemainingBudgetCustomerID($googleSpending[$idx]["grandadmin_customer_id"], $googleSpending[$idx]["grandadmin_customer_name"]);
          if ($find_remaining_budget_customer_id["status"] === "success") {
            $value["remaining_budget_customer_id"] = $find_remaining_budget_customer_id["data"];
          } else {
            $value["remaining_budget_customer_id"] = "";
          } 
        } else {
          $value["remaining_budget_customer_id"] = "";
        }

        $insert_google_spending = $this->resourceModel->addGoogleSpendingData($this->month, $this->year, $value);
        // print_r($insert_google_spending);
        if ($insert_google_spending["status"] === "success") {
          
        }
      }

      $get_google_spending_detail = $this->resourceModel->getTotalDataUpdate("google_spending", $this->month, $this->year);
      if ($get_google_spending_detail["data"]["row_count"] == 0) {
        $this->reportModel->updateReportStatus($this->month, $this->year, "google_spending", "pending");
        $response = array(
          "status" => "error",
          "type" => "alert",
          "data" => "",
          "message" => "Google spending import failed"
        );
        echo json_encode($response);
      } else {
        $this->reportModel->updateReportStatus($this->month, $this->year, "google_spending", "waiting");

        $get_status_resource = $this->resourceModel->getStatusResources($this->month, $this->year);
        $overall_status = $get_status_resource["data"]["overall_status"];
        $waiting_status = 0;
        foreach ($get_status_resource["data"] as $rs => $status) {
          if ($rs === "overall_status") continue;

          if ($rs !== "transfer") {
            if ($status === "waiting") $waiting_status++;
          }
        }

        if ($waiting_status === 7 && ($overall_status !== "waiting" || $overall_status !== "completed")) {
          // update overall status
          $this->reportModel->updateReportStatus($this->month, $this->year, "overall_status", "waiting");
          $overall_status = "waiting";
        }

        $response = array(
          "status" => "success",
          "type" => "alert",
          "overall_status" => $overall_status,
          "message" => "",
          "data" => array(
            "import_total" => $get_google_spending_detail["data"]["row_count"],
            "updated_at" => $get_google_spending_detail["data"]["updated_at"]
          )
        );

        echo json_encode($response);
      }

    } else {
      $response = array(
        "status" => "error",
        "type" => "alert",
        "message" => "Allow only POST method"
      );
      echo json_encode($response);
    }

  }

  public function importFacebookSpending()
  {
    header("Content-Type: application/json");
    if ($_SERVER["REQUEST_METHOD"] === "POST") {
      $allowedFileType = array(
        'application/vnd.ms-excel',
        // 'text/xls',
        // 'text/xlsx',
        // 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      );

      if (!in_array($_FILES["facebookSpendingInputFile"]["type"], $allowedFileType)) {
        $res = array(
          "status" => "error",
          "type" => "alert",
          "message" => "File type not allowed"
        );
        echo json_encode($res);
      }

      $ignore_invalid_data = false;
      if (isset($_POST["ignore_invalid_data"])) {
        $ignore_invalid_data = $_POST["ignore_invalid_data"];
      }
      // $file_name = $_FILES["facebookSpendingInputFile"]["name"];
      $targetFilePath = $_FILES["facebookSpendingInputFile"]["tmp_name"];
      $month = $this->month;
      $year = $this->year;

      $total = 0;
      $valid_total = 0;
      $invalid_total = 0;
      $invalid_lists = array();
      
      $fb_spending_lists = array();
      $data_index = 0;
      
      if (($handle = fopen($targetFilePath, "r")) !== FALSE) {
        while (!feof($handle)) {
          $row = fgetcsv($handle);
          if ($row[0] === "Facebook Ireland Limited") {
            $total++;
            $fb_spending = array(
              "month" => $this->month,
              "year" => $this->year,
              "billing_period" => $row[4],
              "currency" => $row[10],
              "payment_status" => $row[13],
              "facebook_id" => trim($row[16], "_"),
              "spending_total_price" => $this->getPrice($row[26]),
              "campaign_id" => trim($row[18], "_")
            );

            $billing_period = $fb_spending["billing_period"];
            $bp_exp = explode("/", $billing_period);
            $input_date = strtotime($bp_exp[1] . "/" . $bp_exp[0] . "/" . $bp_exp[2]);
            $input_month = date("m", $input_date);
            $input_year = date("Y", $input_date);
            // Check month and year
            if ($input_month != $month || $input_year != $year) {
              array_push($invalid_lists, array(
                "facebook_id" => $fb_spending["facebook_id"],
                "error_message" => "Month and Year (billing_date) do not match with last month and year"
              ));
              $invalid_total++;
              continue;
            }

            array_push($fb_spending_lists, $fb_spending);
            $data_index++;
            $valid_total++;
          }
        }
        fclose($handle);

        if (!$ignore_invalid_data && $invalid_total > 0) {
          $response = array(
            "status" => "error",
            "type" => "modal",
            "data" => array(
              "total" => $total,
              "valid_total" => $valid_total,
              "invalid_total" => $invalid_total,
              "invalid_lists" => $invalid_lists
            )
          );
          echo json_encode($response);
          return 0;
        }

        if ($valid_total == 0) {
          $response = array(
            "status" => "error",
            "type" => "alert",
            "data" => "",
            "message" => "There are not any valid data to import"
          );
          echo json_encode($response);
          return 0;
        }

        // Clear data by month and year
        $this->resourceModel->clearFacebookSpendingByMonthYear($month, $year);

        foreach ($fb_spending_lists as $idx => $fb_spending) 
        {
          // Find grandadmin_customer_id
          $find_customer_id = $this->resourceModel->findCustomerID($fb_spending, "faceboook");
          if ($find_customer_id["status"] === "success") {
            $fb_spending["grandadmin_customer_id"] = $find_customer_id["data"]["CustomerID"];
          } else {
            $fb_spending["grandadmin_customer_id"] = "";
          }

          // Find grandadmin_customer_name
          if (empty($fb_spending["grandadmin_customer_id"])) {
            $fb_spending["grandadmin_customer_name"] = "";
          } else {
            $find_customer_name = $this->resourceModel->findCustomerName($fb_spending, "facebook");
            if (!empty($find_customer_name) && $find_customer_name["status"] === "success") {
              $fb_spending["grandadmin_customer_name"] = $find_customer_name["CustomerName"];
            } else {
              $fb_spending["grandadmin_customer_name"] = "";
            }
          }

          // Find remaining_budget_customer_id
          if ($fb_spending["grandadmin_customer_name"] !== "" && $fb_spending["grandadmin_customer_id"] !== "") {
            $find_remaining_budget_customer_id = $this->resourceModel->findRemainingBudgetCustomerID();
            if ($find_remaining_budget_customer_id["status"] === "success") {
              $fb_spending["remaining_budget_customer_id"] = $find_remaining_budget_customer_id["data"];
            } else {
              $fb_spending["remaining_budget_customer_id"] = "";
            } 
          } else {
            $fb_spending["remaining_budget_customer_id"] = "";
          }

          $insert_facebook_spending = $this->resourceModel->insertFacebookSpending($month, $year, $fb_spending);
          if ($insert_facebook_spending["status"] === "success") { }
        }

        $get_facebook_spending_detail = $this->resourceModel->getTotalDataUpdate("facebook_spending", $month, $year);
        if ($get_facebook_spending_detail["data"]["row_count"] == 0) {
          $this->reportModel->updateReportStatus($month, $year, "facebook_spending", "pending");
          $response = array(
            "status" => "error",
            "type" => "alert",
            "message" => "Facebook spending import was failed"
          );
          echo json_encode($response);
        } else {
          $this->reportModel->updateReportStatus($month, $year, "facebook_spending", "waiting");
          $get_status_resource = $this->resourceModel->getStatusResources($month, $year);
          $overall_status = $get_status_resource["data"]["overall_status"];
          $waiting_status = 0;
          foreach ($get_status_resource["data"] as $rs => $status) {
            if ($rs === "overall_status") continue;
  
            if ($rs !== "transfer") {
              if ($status === "waiting") $waiting_status++;
            }
          }
  
          if ($waiting_status === 7 && ($overall_status !== "waiting" || $overall_status !== "completed")) {
            $this->reportModel->updateReportStatus($this->month, $this->year, "overall_status", "waiting");
            $overall_status = "waiting";
          }
  
          $response = array(
            "status" => "success",
            "type" => "alert",
            "overall_status" => $overall_status,
            "message" => "",
            "data" => array(
              "import_total" => $get_facebook_spending_detail["data"]["row_count"],
              "updated_at" => $get_facebook_spending_detail["data"]["updated_at"]
            )
          );
  
          echo json_encode($response);
        }

      } else {
        $res = array(
          "status" => "error",
          "type" => "alert",
          "message" => "Can not access file"
        );
        echo json_encode($res);
      }
    } else {
      $res = array(
        "status" => "error",
        "type" => "alert",
        "meesage" => "Allow only POST method"
      );
      echo json_encode($res);
    }
  }
  
  // Get report status
  public function getStatusResources($year = "", $month = "")
  {
    if ($_SERVER["REQUEST_METHOD"] === "GET") {
      header("Content-Type: application/json");
      
      if (empty($month) || empty($year)) {
        $result = array(
          "status" => "error",
          "message" => "Required month and year to get status resource"
        );
        echo json_encode($result);
        exit;
      }

      if (intval($month + $year) > intval($this->month + $this->year)) {
        $result = array(
          "status" => "error",
          "message" => "These month and year input are more than current month and year"
        );
        echo json_encode($result);
        exit;
      }

      $statusResources = $this->resourceModel->getStatusResources($month, $year);
      if ($statusResources["status"] === 'fail') {
        $result = array(
          "status" => "error",
          "message" => "Can not get report status!"
        );
        echo json_encode($result);
        exit;
      }

      $reportStatus = array();
      $waiting_status = 0;
      foreach ($statusResources["data"] as $key => $value) {
        if ($key === "overall_status") continue;

        if ($key === "transfer") {
          $key = "wallet_" . $key;
        }

        // re-check all resources
        $getDatatDetail = $this->resourceModel->getTotalDataUpdate($key, $month, $year);
        if ($getDatatDetail["data"]["row_count"] == 0) {
          $this->reportModel->updateReportStatus($month, $year, $key, "pending");
          $value = "pending";
        }

        $reportStatus[$key] = array(
          "status" => $value,
          "total" => $getDatatDetail["data"]["row_count"],
          "updated_at" => $getDatatDetail["data"]["updated_at"]
        );

        if ($key !== "wallet_transfer") {
          if ($value === "waiting") {
            $waiting_status++;
          }
        }

      }

      // check overall status for enable generate button
      $overall_status = $statusResources["data"]["overall_status"];
      if ($waiting_status === 7 && ($overall_status !== "waiting" || $overall_status !== "completed")) {
        // update overall status
        $this->reportModel->updateReportStatus($month, $year, "overall_status", "waiting");
        $overall_status = "waiting";
      }

      $result = array(
        "status" => "success",
        "message" => "",
        "overall_status" => $overall_status,
        "data" => $reportStatus
      );

      echo json_encode($result);

    } else {
      $result = array(
        "status" => "fail",
        "message" => "Allowed only GET Method"
      );
      echo json_encode($result);
    }
    

  }


  function getPrice($priceText)
  {
    return preg_replace('/[^0-9.]/', '', $priceText); 
  }


}
