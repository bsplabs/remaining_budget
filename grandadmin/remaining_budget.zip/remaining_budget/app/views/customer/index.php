<link href="<?php echo URLROOT; ?>public/css/customer.css" rel="stylesheet">

<?php require_once APPROOT . "/views/layout/head.php"; ?>

<br>
<div class="container-fluid mt-2 customer-page">
  <div class="row">
    <div class="col-md-6">
      <h2>Customers</h2>
      <p class="mb-0">This page show you all customers and you could upload customer resources file to edit customers</p>
    </div>
    <div class="col-md-6 text-end">
      <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalCustomerUpload"><i class='bx bx-add-to-queue'></i> Add / Replace</button>
    </div>
  </div>

  <hr>

  <div class="table-responsive mt-3">
    <table class="table table-bordered table- text-nowrap table-striped table-hover">
      <thead>
        <tr>
          <th scope="col">Parent Customer ID</th>
          <th scope="col">Customer ID</th>
          <th scope="col">Customer Name</th>
          <th scope="col">Offset Acct</th>
          <th scope="col">Offset Acct Name</th>
          <th scope="col">Company</th>
          <th scope="col">Payment Method</th>
          <th scope="col">Created at</th>
          <th scope="col">Updated at</th>
          <th scope="col">Updated by</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if (empty($data["customers"]["data"])) {
          echo "<tr>";
          echo "<td class='text-center' colspan='3'>No Data</td>";
          echo "</tr>";
        } else {
          foreach ($data["customers"]["data"] as $customer) {
            echo "<tr>";
            echo "<td>" . $customer["parent_id"] . "</td>";
            echo "<td>" . $customer["grandadmin_customer_id"] . "</td>";
            echo "<td>" . $customer["grandadmin_customer_name"] . "</td>";
            echo "<td>" . $customer["offset_acct"] . "</td>";
            echo "<td>" . $customer["offset_acct_name"] . "</td>";
            echo "<td>" . $customer["company"] . "</td>";
            echo "<td>" . $customer["payment_method"] . "</td>";
            echo "<td>" . $customer["created_at"] . "</td>";
            echo "<td>" . $customer["updated_at"] . "</td>";
            echo "<td>" . $customer["updated_by"] . "</td>";
            echo "</tr>";
          }
        }
        ?>
      </tbody>
    </table>
  </div>

  <div class="row mt-4">
    <nav aria-label="Page navigation example">
      <ul class="pagination justify-content-center">
        <li class="page-item disabled">
          <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
        </li>
        <li class="page-item"><a class="page-link" href="#">1</a></li>
        <li class="page-item"><a class="page-link" href="#">2</a></li>
        <li class="page-item"><a class="page-link" href="#">3</a></li>
        <li class="page-item"><a class="page-link" href="#">4</a></li>
        <li class="page-item"><a class="page-link" href="#">5</a></li>
        <li class="page-item">
          <a class="page-link" href="#">Next</a>
        </li>
      </ul>
    </nav>
  </div>

  <div class="modal fade" id="modalCustomerUpload" tabindex="-1" aria-labelledby="modalCustomerUploadLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="staticBackdropLabel">Upload Customer Resources</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form>
            <div class="mb-3">
              <label for="exampleFormControlInput1" class="form-label">Choose your file type to upload</label>
              <select class="form-select" aria-label="Default select example">
                <!-- <option selected>Open this select menu</option> -->
                <option selected value="customer_id_mapping">Customer ID Mapping</option>
                <option value="post_paid_account">Post-paid Account</option>
                <option value="rpmax_account">RPMAX Account</option>
              </select>
            </div>
            <div class="mb-3">
              <label class="form-label">Browse your computer</label>
              <div class="upload-container">
                <div class="border-container">
                  <input type="file" id="customer-file-upload" class="form-control">
                </div>
              </div>
            </div>
          </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Upload</button>
        </div>
      </div>
    </div>
  </div>

</div>

<?php require_once APPROOT . "/views/layout/script.php"; ?>

<script src="<?php echo URLROOT; ?>public/js/customer.js"></script>