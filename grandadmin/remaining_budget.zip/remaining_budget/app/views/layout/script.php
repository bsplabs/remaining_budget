<script src="<?php echo BASE_URL; ?>/public/vendors/jquery-3.6.0.min.js"></script>
<script src="<?php echo BASE_URL; ?>/public/vendors/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo BASE_URL; ?>/public/vendors/sweetalert2.all.min.js"></script>
<script src="<?php echo BASE_URL; ?>/public/js/main.js"></script>