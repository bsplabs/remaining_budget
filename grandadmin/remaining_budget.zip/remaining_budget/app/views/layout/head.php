</head>

<body id="body-pd">
  <!-- <div class="container-fluid bg-dark">
    <h1>GrandAdmin</h1>
  </div> -->

  <div class="container-fluid">
    <?php require_once APPROOT . "/views/layout/navbar.php" ?>