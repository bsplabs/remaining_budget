<?php require_once APPROOT . "/views/layout/head.php"; ?>

<br>
<h1 class="text-danger">SOMETHING WENT WRONG !</h1>

<?php require_once APPROOT . "/views/layout/script.php"; ?>