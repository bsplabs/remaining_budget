<?php require_once APPROOT . "/views/layout/head.php"; ?>

<br>
<h1 class="text-info">Processing Data...</h1>

<?php require_once APPROOT . "/views/layout/script.php"; ?>